#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include "list.h"

struct node
{
	int length;
	int count;
	int start;
	void **data;
	struct node *next;
	struct node *prev;
};

typedef struct node NODE;

struct list
{
	int count;
	NODE *head;
	NODE *tail;
};

//O(1)
NODE *createNode (int length)
{
	NODE *np = malloc (sizeof(NODE));
	assert (np != NULL);
	np -> data = malloc (sizeof(void**) * length);
	np -> count = 0;
	np -> start = 0;
	np -> length = length;
	np -> next = NULL;
	np -> prev = NULL;
	return np;
}

//O(1)
LIST *createList (void)
{
	LIST *lp;
	lp = malloc (sizeof (LIST));
	assert (lp != NULL);
	lp -> count = 0;
	lp -> head = lp -> tail = createNode(8);
	return lp;
}

//O(n)
void destroyList (LIST *lp)
{
	assert (lp != NULL);
	NODE *temp;
	while (lp -> head != NULL)
	{
		temp = lp -> head;
		lp -> head = lp -> head -> next;
		free (temp -> data);
		free (temp);
	}
	free (lp);
	return;
}

//O(1)
int numItems (LIST *lp)
{
	assert (lp != NULL);
	return lp -> count;
}

//O(1)
void addFirst (LIST *lp, void *item)
{
	assert (lp != NULL && item != NULL);
	if (lp -> head -> count == lp -> head -> length)
	{
		NODE *temp = createNode (lp -> head -> length * 2);
		temp -> next = lp -> head;
		lp -> head = temp;
		temp -> next -> prev = temp;
	}
	int i = ((lp -> head -> start + lp -> head -> length - 1) % lp -> head -> length);
	lp -> head -> data [i] = item;
	lp -> head -> start = i;
	lp -> head -> count++;
	lp -> count++;
}

//O(1)
void addLast (LIST *lp, void *item)
{
	assert (lp != NULL && item != NULL);
        if (lp -> tail -> count == lp -> tail -> length)
        {
                NODE *temp = createNode (lp -> tail -> length * 2);
                temp -> prev = lp -> tail;
                lp -> tail -> next = temp;
                lp -> tail = temp;
        }
        int i = ((lp -> tail -> start + lp -> tail -> count) % lp -> tail -> length);
        lp -> tail -> data [i] = item;
        lp -> tail -> count++;
        lp -> count++;
}

//O(1)
void *removeFirst (LIST *lp)
{
	assert (lp != NULL);
	if (lp -> head -> count == 0)
	{
		lp -> head = lp -> head -> next;
		free (lp -> head -> prev);
		lp -> head -> prev = NULL;
	}
	int i = lp -> head -> start;
	int j = (i + 1) % lp -> head -> length;
	lp -> head -> start = j;
	void *copy = lp -> head -> data[i];
	lp -> head -> count--;
	lp -> count--;
	return copy;
}

//O(1)
void *removeLast (LIST *lp)
{
	assert (lp != NULL);
        if (lp -> tail -> count == 0)
        {
		NODE *temp = lp -> tail;
                lp -> tail = lp -> tail -> prev;
		lp -> tail -> next = NULL;
                free (temp -> data);
                free (temp);
        }
        int i = ((lp -> tail -> start + lp -> tail -> count) % lp -> tail -> length);
        void *copy = lp -> tail -> data[i];
        lp -> tail -> count--;
        lp -> count--;
        return copy;
}

//O(logn)
void *getItem (LIST *lp, int index)
{
	assert (lp != NULL);
	assert (index >= 0 && index < lp->count);
	NODE *temp = lp -> head;
	while (index >= temp -> count)
	{
		index -= temp -> count;
		temp = temp -> next;
	}
	void *copy = temp -> data[(temp -> start + index) % temp -> length];
	return copy;
}

//O(logn)
void setItem(LIST *lp, int index, void *item)
{
	assert (lp != NULL && item != NULL);
	assert (index >= 0 && index < lp -> count);
	NODE* temp = lp -> head;
	while (index >= temp -> count)
	{
		index -= temp -> count;
		temp = temp -> next;
	}
	temp -> data[(temp -> start + index) % temp -> length] = item;
}
