#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>
#include "list.h"

struct node
{
	void *data;
	struct node *next;
	struct node *prev;
};

typedef struct node NODE;

struct list
{
	int count;
	struct node *head;
	int (*compare)();
};

static NODE *search (LIST *lp, void *item);

// Big-O Runtime: O(1)

LIST *createList (int (*compare)())
{
	LIST *lp;
	lp = malloc (sizeof(LIST));
	assert (lp != NULL);
	NODE *head;
	head = malloc (sizeof(NODE));
	assert (head != NULL);
	lp -> head = head;
	lp -> head -> prev = lp -> head;
	lp -> head -> next = lp -> head;
	lp -> count = 0;
	lp -> compare = compare;
	return lp;
}

// Big-O Runtime: O(n)

void destroyList (LIST *lp)
{
	assert (lp != NULL);
	NODE *np = lp -> head;
	while (np -> next != np)
	{
		np -> next = np -> next -> next;
		free (np -> next -> prev);
		np -> next -> prev = np;
		lp -> count--;
	}
	free (lp -> head);
	free (lp);
}

// Big-O Runtime: O(1)

int numItems (LIST *lp)
{
	assert (lp != NULL);
	return lp -> count;
}

// Big-O Runtime: O(1)

void addFirst (LIST *lp, void *item)
{
	assert (lp != NULL && item != NULL);
	NODE *temp;
	temp = malloc (sizeof (NODE));
	assert (temp != NULL);
	temp -> data = item;
	temp -> prev = lp -> head;
	temp -> next = lp -> head -> next;
	lp -> head -> next -> prev = temp;
	lp -> head -> next = temp;
	lp -> count++;
}

// Big-O Runtime: O(1)

void addLast (LIST *lp, void *item)
{
	assert (lp != NULL && item != NULL);
        NODE *temp;
        temp = malloc (sizeof (NODE));
        assert (temp != NULL);
        temp -> data = item;
        temp -> next = lp -> head;
        temp -> prev = lp -> head -> prev;
        lp -> head -> prev -> next = temp;
        lp -> head -> prev = temp;
        lp -> count++;
}

// Big-O Runtime: O(1)

void *removeFirst (LIST *lp)
{
	assert (lp != NULL);
	NODE *np = lp -> head;
	void *ret = np -> next -> data;
	assert (np -> next != np);
	np -> next = np -> next -> next;
	free (np -> next -> prev);
	np -> next -> prev = np;
	lp -> count--;
	return ret;
}

//Big-O Runtime: O(1)

void *removeLast (LIST *lp)
{
	assert (lp != NULL);
	NODE *np = lp -> head;
	void *ret = np -> prev -> data;
	assert (np -> prev != np);
	np -> prev = np -> prev -> prev;
	free (np -> prev -> next);
	np -> prev -> next = np;
	lp -> count--;
	return ret;
}

// Big-O Runtime: O(1)

void *getFirst (LIST *lp)
{
	assert (lp != NULL);
	return lp -> head -> next -> data;
}

// Big-O Runtime: O(1)

void *getLast (LIST *lp)
{
	assert (lp != NULL);
	return lp -> head -> prev -> data;
}

// Big-O Runtime: O(n)

void removeItem (LIST *lp, void *item)
{
	assert (lp != NULL && lp -> compare != NULL);
	NODE *elt = search(lp, item);
	if (elt != NULL)
	{
		elt -> prev -> next = elt -> next;
		elt -> next -> prev = elt -> prev;
		free (elt);
		lp -> count--;
	}
}

// Big-O Runtime: O(n)

void *findItem (LIST *lp, void *item)
{
	assert (lp != NULL && lp -> compare != NULL && item != NULL);
	NODE *np = search(lp, item);
	if (np == NULL)
		return NULL;
	return np -> data;
}

// Big-O Runtime: O(n)

void *getItems (LIST *lp)
{
	assert (lp != NULL);
	void **items;
	items = malloc (sizeof (void *) *lp -> count);
	assert (items != NULL);
	int i = 0;
	NODE *np = lp -> head -> next;
	while (np -> next != lp -> head)
	{
		items[i] = np -> data;
		i++;
	}
	return items;
}

static NODE *search (LIST *lp, void *item)
{
	NODE *np = lp -> head -> next;
	while (np != lp -> head)
	{
		if ((*lp -> compare) (np -> data, item) == 0)
		{
			return np;
		}
		np = np -> next;
	}
	return NULL;
}
