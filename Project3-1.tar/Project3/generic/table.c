#include "set.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

struct set
{
	int count;
	int length;
	char **data;
	char *flags;
	int (*compare)();
	unsigned (*hash)();
};

static int search (SET* sp, void* elt, bool *found);

//Big-O O(n)
//Creating the hashtsable
//Has an identifier array

SET *createSet (int maxElts, int (*compare)(), unsigned (*hash)())
{
	int i;
	SET *sp;
	sp = malloc (sizeof(SET));
	assert (sp != NULL);

	sp -> count = 0;
	sp -> length = maxElts;
	sp -> compare = compare;
	sp -> hash = hash;

	sp -> flags = malloc (sizeof(char) *maxElts);
	assert (sp -> flags != NULL);

	sp -> data = malloc (sizeof(char *) *maxElts);
	assert (sp -> data != NULL);

	for (i = 0; i < maxElts; i++)
	{
		sp -> flags[i] = 'E';
	}
	return sp;
}

//Big-O O(n)
//Frees the data point, identifier array, and hashtable

void destroySet (SET *sp)
{
	assert (sp != NULL);
	free (sp -> data);
	free (sp -> flags);
	free (sp);
}

//Big-O O(1)
//Get number of elements in the set

int numElements (SET *sp)
{
	assert (sp != NULL);
	return sp -> count;
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Add elements to the set

void addElement (SET *sp, void *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	int index = search (sp, elt, &found);
	if (!found)
	{
		sp -> data[index] = elt;
		sp -> flags[index] = 'F';
		sp -> count++;   //Increment Count
	}
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Removes element from the set

void removeElement (SET *sp, void *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	int index = search (sp, elt, &found);
	if (found)
	{
		sp -> flags[index] = 'D';
		sp -> count--;   //Decrement Count
	}
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Looks for an element and returns the pointer of the element

void *findElement (SET *sp, void *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	int index = search (sp, elt, &found);
	if (!found)
	{
		return NULL;
	}
	return sp -> data[index];
}

//Big-O O(n)
//Copy of the elements

void *getElements (SET *sp)
{
	assert (sp != NULL);
	void **dataCopy;
	dataCopy = malloc (sizeof (void *) *sp -> length);
	int i; 
	int j = 0;

	for (i = 0 ; i < sp -> length; i++)
	{
		if (sp -> flags[i] == 'F')
		{
			dataCopy[j] = sp -> data[i];
			j++;
		}
	}
	return dataCopy;
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Looks for specific element in hashtable
//Lets user know the outcome

static int search (SET *sp, void *elt, bool *found)
{
	assert ((sp != NULL) && (elt != NULL));
	int index = (*sp -> hash)(elt) % sp -> length;
	int deleted = -1;
	int locn;
	int i = 0;
	while (i < sp -> length)
	{
		locn = (index + 1) % (sp -> length);
		if (sp -> flags[locn] == 'D')
		{
			if (deleted == -1)
			{
				deleted = locn;
			}
		}	
		else if (sp -> flags[locn] == 'E')
		{
			*found = false;
			if (deleted == -1)
			{
				return locn;
			}
			return deleted;
		}
		else if ((*sp -> compare)(sp -> data[locn], elt) == 0)
		{
			*found = true;
			return locn;
		}
		i++;
	}
	*found = false;
	return deleted;
}
