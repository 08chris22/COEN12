#include "set.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

struct set
{
	int count;
	int length;
	char* *data;
	char *flags;
};

static unsigned strhash(char *s);
static int search (SET* sp, char* elt, bool *found);

//Big-O O(n)
//Creates hashtable with identifier array

SET *createSet (int maxElts)
{
	int i;
	SET *sp;
	sp = malloc(sizeof(SET));
	assert (sp != NULL);

	sp -> count = 0;
	sp -> length = maxElts;
	sp -> flags = malloc(sizeof(char) *maxElts);
	assert (sp -> flags != NULL);

	sp -> data = malloc(sizeof(char *) *maxElts);
	assert (sp -> data != NULL);

	for (i = 0; i < maxElts; i++)
	{
		sp -> flags[i] = 'E';
	}
	return sp;
}

//Big-O O(n)
//Free's data point, identifier array, and hashtable

void destroySet (SET *sp)
{
	assert (sp != NULL);
	int i;
	for (i = 0; i < sp -> length; i++)
	{
		if (sp -> flags[i] == 'F')
		{
			free (sp -> data[i]);
		}
	}
	free (sp -> data);
	free (sp -> flags);
	free (sp);
}

//Big-O O(1)
//Gets the number of elements in the set

int numElements (SET *sp)
{
	assert (sp != NULL);
	return sp -> count;
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Adds element to the set

void addElement (SET *sp, char *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	char *newElt;
	int index = search (sp, elt, &found);
	if (!found)
	{
		newElt = strdup (elt);
		assert (newElt != NULL);
		sp -> data[index] = newElt;
		sp -> flags[index] = 'F';
		sp -> count++;   //Increment count
	}
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Removes element from the set

void removeElement (SET *sp, char *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	int index = search (sp, elt, &found);
	if (found)
	{
		free (sp -> data[index]);
		sp -> flags[index] = 'D';
		sp -> count--;    //Decrement count
	}
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Find element in set and tells its pointer

char *findElement (SET *sp, char *elt)
{
	assert ((sp != NULL) & (elt != NULL));
	bool found;
	int index = search (sp, elt, &found);
	if (!found)
	{
		return NULL;
	}
	return sp -> data[index];
}

//Big-O O(n)
//Copy of the elements in the set

char **getElements (SET *sp)
{
	assert (sp != NULL);
	char **dataCopy;
	dataCopy = malloc (sizeof(char *) *sp -> length);
	int i;
	int j = 0;

	for (i = 0; i < sp -> length; i++)
	{
		if (sp -> flags[i] == 'F')
		{
			dataCopy[j] = sp -> data[i];
			j++;
		}
	}
	return dataCopy;
}

//Big-O Average O(1)
//Big-O Worst O(n)
//Searches for the element in the hashtable
//Lets user know its location

static int search (SET *sp, char *elt, bool *found)
{
	assert ((sp != NULL) && (elt != NULL));
	int index = strhash (elt) % sp -> length;
	int deleted = -1;
	int locn;
	int i = 0;
	while (i < sp -> length)
	{
		locn = (index + i) % (sp -> length);
		if (sp -> flags[locn] == 'D')
		{
			if (deleted == -1)
			{
				deleted = locn;
			}
		}
		else if (sp -> flags [locn] == 'E')
		{
			*found  = false;
			if (deleted == -1)
			{
				return locn;
			}
			return deleted;
		}
		else if (strcmp (sp -> data [locn], elt) == 0)
		{
			*found = true;
			return locn;
		}
		i++;
	}
	*found = false;
	return deleted;
}

static unsigned strhash (char *s)
{
	unsigned hash = 0;
	assert (s != NULL);
	while (*s != '\0')
		hash = 31 * hash + *s++;
	return hash;
}
