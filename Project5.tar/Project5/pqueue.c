#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "pqueue.h"

static int parent(int i);
static int left(int i);
static int right(int i);

struct pqueue
{
	int count;
	int length;
	void** data;
	int (*compare)();
};

PQ *createQueue (int (*compare)())
{
	PQ *pq = malloc (sizeof(PQ));
	assert (pq != NULL);
	pq -> compare = compare;
	pq -> count = 0;
	pq -> length = 10;
	pq -> data = malloc (sizeof(void*)*10);
	assert (pq -> data != NULL);
	return pq;
}

void destroyQueue (PQ *pq)
{
	assert (pq != NULL);
	int i;
	for (i = 0; i < pq -> count; i++)
	{
		free (pq -> data[i]);
	}
	free (pq -> data);
	free (pq);
	return;
}

int numEntries (PQ *pq)
{
	assert (pq != NULL);
	return pq -> count;
}

void addEntry (PQ *pq, void *entry)
{
	assert (pq != NULL);
	if (pq -> count == pq -> length)
	{
		pq -> length *= 2;
		pq -> data = realloc (pq -> data, sizeof (void *) *pq -> length);
	}
	pq -> data[pq -> count] = entry;
	int index;
	while (pq -> count != 0 && (*pq -> compare)(pq -> data[parent(index)], pq -> data[index]) > 0)
	{
		void* swapData = pq -> data[index];
		pq -> data[index] = pq -> data [parent(index)];
		pq -> data[parent(index)] = swapData;
		index = parent(index);
	}
	pq -> count++;
	return;
}

void *removeEntry (PQ *pq)
{
	assert (pq != NULL);
	void *returnData = pq -> data[0];
	pq -> data[0] = pq -> data[pq -> count - 1];
	int index = 0;
	while (left(index) <= pq -> count - 1)
	{
		int smallerChildIndex = left(index);
		if (right(index) <= pq -> count - 1)
		{
			if ((*pq -> compare) (pq -> data[right(index)], pq -> data [left(index)]) < 0)
			{
				smallerChildIndex = right(index);
			}
		}
		if ((*pq -> compare) (pq -> data[index], pq -> data[smallerChildIndex]) < 0)
		{
			break;
		}
		else
		{
			void* swapData = pq -> data[index];
			pq -> data[index] = pq -> data[smallerChildIndex];
			pq -> data[smallerChildIndex] = swapData;
		}
		index = smallerChildIndex;
	}
	pq -> count--;
	return returnData;
}

static int parent (int i)
{
	return (i-1)/2;
}

static int left (int i)
{
	return (i*2)+1;
}

static int right (int i)
{
	return (i*2)+2;
}
