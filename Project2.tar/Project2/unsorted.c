// Christian Garcia Project 2 Unsorted Wednesday 5:15PM April 14, 2021


#include "set.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct set   //Struct that creates the array
{
	int count;
	int length;
	char* *data;
};

typedef struct set SET;

static int search (SET *sp, char *elt);

SET *createSet (int maxElts)
{
	SET *sp;
	sp = malloc(sizeof(SET));
	assert (sp!=NULL);

	sp->count = 0;
	sp->length = maxElts;

	sp->data = malloc(sizeof(char *) *maxElts);
	assert (sp->data!=NULL);
	return sp;
}

void destroySet (SET *sp)   //Fress the pointer once it gets to the end
{
	int i;
	assert (sp != NULL);

	for(i = 0; i < sp->count; i++)
	{
		free (sp->data[i]);
	}
	
	free(sp->data);
	free(sp);
}

int numElements (SET *sp)
{
	assert (sp != NULL);
	return (sp -> count);
}

void addElement (SET *sp, char *elt)  //Searches for an element on the list, either adds it or increments is
{
	assert ((elt!=NULL) && (sp!=NULL) && (sp->length > sp->count));
	char *NewElt;
	int posn;
	posn = search(sp, elt);
	if (posn == -1)
	{
		NewElt = strdup(elt);
		assert(NewElt != NULL);
		sp->data[sp->count++] = NewElt;
	}
}

void removeElement (SET *sp, char *elt)      //Searches for an element deletes and decrements
{
	assert((sp != NULL) && (elt != NULL));
	int locn;
	locn = search(sp,elt);
	if (locn != -1)
	{
		free(sp->data[locn]);
		sp->data[locn] = sp -> data[--sp->count];
	}
}

char *findElement (SET *sp, char *elt)    //Searches for an element and returns its location if found
{
	assert ((sp != NULL) && (elt != NULL));
	int locn;
	locn = search (sp,elt);
	if (locn == -1)
		return NULL;
	return sp->data[locn];
}

char **getElements (SET *sp)      //Searches for an element and makes a copy of it
{
	assert (sp != NULL);
	char ** DataCopy;
	DataCopy = malloc(sizeof(char *)*sp -> length);
	assert (DataCopy != NULL);
	int i;
	for (i = 0; i < sp->count; i++)
		DataCopy[i] = sp->data[i];
	return DataCopy;
}

static int search (SET *sp, char *elt)      //Looks for an element and returns its location
{
	int i;
	for (i = 0; i < sp->count; i++)
	{
		if(strcmp(sp->data[i], elt) == 0)
			return i;
	}
	return -1;
}
