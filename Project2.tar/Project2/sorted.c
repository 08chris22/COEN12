// Christian Garcia Project 2 Sorted Wednesday 5:15PM April 14, 2021

#include "set.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

struct set    //Struct that creates the array
{
	int count;
	int length;
	char* *data;
};

typedef struct set SET;

static int search (SET *sp, char *elt, bool *found);

SET *createSet (int maxElts)
{
	SET *sp;
	sp = malloc(sizeof(SET));
	assert (sp != NULL);
	sp -> count = 0;
	sp -> length = maxElts;

	sp -> data = malloc(sizeof(char *) * maxElts);
	assert (sp -> data != NULL);
	return sp;
}

void destroySet (SET *sp)    //Fress the pointer once it gets to the end
{
	int i;
	for (i = 0; i < sp -> count; i++)
		free (sp->data[i]);
	free (sp-> data);
	free (sp);
}

int numElements (SET *sp)
{
	assert (sp != NULL);
	return sp->count;
}

void addElement (SET *sp, char *elt)     //Searches for an element on the list, either adds it or increments is
{
	assert ((elt != NULL) && (sp != NULL) && (sp -> length > sp -> count));
	char * NewElt;
	int posn;
	int i;
	bool found;
	posn = search (sp, elt, &found);
	if (!found)
	{
		NewElt = strdup (elt);
		assert (NewElt != NULL);
		for (i = sp->count; i > posn; i--)
			sp->data[i] = sp->data[i-1];
		sp -> data[posn] = NewElt;
		sp -> count++;
	}
}

void removeElement (SET *sp, char *elt)      //Searches for an element deletes and decrements
{
	assert ((sp != NULL) && (elt != NULL));
	int locn;
	int i;
	bool found;
	locn = search (sp,elt,&found);
	if (found)
	{
		free (sp-> data[locn]);
		for (i = locn+1; i < sp->count; i++)
			sp->data[i-1] = sp->data[i];
		sp->count--;
	}
}

char *findElement (SET *sp, char *elt)      //Searches for an element and returns its location if found

{
	assert ((sp != NULL) && (elt != NULL));
	int locn;
	bool found;
	locn = search (sp, elt, &found);
	if (!found)
	{
		return NULL;
	}
	return sp -> data[locn];
}

char **getElements (SET *sp)      //Searches for an element and makes a copy of it
{
	assert (sp != NULL);
	char ** DataCopy;
	DataCopy= malloc(sizeof(char *) * sp -> length);
	assert (DataCopy != NULL);
	int i;
	for (i = 0; i < sp-> count ; i++)
	{
		DataCopy[i] = sp->data[i];
	}
	return DataCopy;
}

static int search (SET *sp, char *elt, bool *found)      //Looks for an element and returns its location
{
	int lo, hi, mid, diff;
	lo = 0;
	hi = sp->count - 1;

	while(lo <= hi)
	{
		mid = (lo + hi)/2;
		diff = strcmp (elt, sp -> data[mid]);
		if (diff<0)
		{
			hi = mid - 1;
		}
		else if (diff > 0)
		{
			lo = mid + 1;
		}
		else
		{
			*found = true;
			return mid;
		}
	}
	*found = false;
	return lo;
}
