#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdbool.h>
#include "set.h"

#define empty 0
#define filled 1
#define removed 2

static int search (SET* sp, void* elt, bool* found);
static int partition (SET* sp, void** elts, int low, int high);
static void quicksort (SET* sp, void** elts, int low, int high);

struct set
{
	void** data;
	char* flag;
	int length;
	int count;
	int (*compare)();
	unsigned (*hash)();
};

SET *createSet (int maxElts, int (*compare)(), unsigned (*hash)())
{
	SET *sp = (SET*) malloc (sizeof (SET));
	assert (sp != NULL);
	sp -> count = 0;
	sp -> length = maxElts;
	sp -> compare = compare;
	sp -> hash = hash;
	sp -> data = malloc(sizeof(void*)*maxElts);
	sp -> flag = (char*) malloc (sizeof (char) *maxElts);
	assert (sp -> data != NULL && sp -> flag != NULL);
	int i;
	for (i = 0; i < sp -> length; i++)
	{
		sp -> flag[i] = empty;
	}
	return sp;
}

void destroySet (SET *sp)
{
	assert (sp != NULL);
	int i;
	for (i = 0; i < sp -> count; i++)
	{
		if (sp -> data[i] == NULL)
		{
			free (sp -> data[i]);
		}
	}
	free (sp -> data);
	free (sp -> flag);
	free (sp);
	return;
}

int numElements (SET *sp)
{
	assert (sp != NULL);
	return sp -> count;
}

void addElement (SET *sp, void *elt)
{
	assert (sp != NULL && elt != NULL && sp -> count < sp -> length);
	bool find = false;
	int index = search (sp, elt, &find);
	if (find == false)
	{
		sp -> data[index] = elt;
		sp -> flag[index] = filled;
		sp -> count++;
	}
	return;
}

void removeElement (SET *sp, void *elt)
{
	assert (sp != NULL && elt != NULL);
	bool find = false;
	int index = search (sp, elt, &find);
	if (find == false)
	{
		return;
	}
	sp -> flag[index] = removed;
	sp -> count--;
	return;
}

void *findElement (SET *sp, void *elt)
{
	assert (sp != NULL && elt != NULL);
	bool find = false;
	int index = search (sp, elt, &find);
	if (find == false)
	{
		return NULL;
	}
	return sp -> data[index];
}

void *getElements (SET *sp)
{
	assert (sp != NULL);
	void** elts = malloc (sizeof (void*) *sp -> count);
	assert (elts != NULL);
	int i, j;
	for (i = 0, j = 0; i < sp -> length; i++)
	{
		if (sp -> flag[i] == filled)
		{
			elts[j++] = sp -> data[i];
		}
	}
	quicksort (sp, elts, 0, sp -> count - 1);
	return elts;
}

static int search(SET *sp, void *elt, bool* find)
{
	assert (sp != NULL && elt != NULL);
	int index = (*sp -> hash) (elt) % sp -> length;
	int trials = 0;
	int deletedSlot = -1;
	while (trials < sp -> length)
	{
		if (sp -> flag[index] == empty)
		{
			*find = false;
			return deletedSlot != -1 ? deletedSlot : index;
		}
		else if (sp -> flag[index] == removed)
		{
			trials++;
			if (deletedSlot == -1)
			{
				deletedSlot = index;
			}
			index = (index + 1) % sp -> length;
		}
		else
		{
			if ((*sp -> compare) (sp -> data[index], elt) == 0)
			{
				*find = true;
				return index;
			}
			else 
			{
				index = (index + 1) % sp -> length;
				trials++;
			}
		}
	}
	*find = false;
	return deletedSlot;
}

static int partition (SET* sp, void** elts, int low, int high)
{
	assert (sp != NULL);
	void* pivot = elts[high];
	int smaller = low - 1;
	int i;
	for (i = low; i <= high - 1; i++)
	{
		if ((*sp -> compare) (elts[i], pivot) <= 0)
		{
			smaller++;
			void* temp = elts[smaller];
			elts[smaller] = elts[i];
			elts[i] = temp;
		}
	}
	void* swap = elts[smaller + 1];
	elts[smaller + 1] = elts[high];
	elts[high] = swap;
	return smaller + 1;
}

static void quicksort (SET* sp, void** elts, int low, int high)
{
	assert (sp != NULL);
	if (low < high)
	{
		int partitionIndex = partition (sp, elts, low, high);
		quicksort (sp, elts, low, partitionIndex - 1);
		quicksort (sp, elts, partitionIndex + 1, high);
	}
	return;
} 
